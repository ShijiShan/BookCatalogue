﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BookCatalogue.Models;

namespace BookCatalogue.DBContexts
{
	public class BookDetails : DbContext

    {
        public BookDetails(DbContextOptions<BookDetails> options) : base(options)
        {
        }
        public DbSet<Book> Books { get; set; }
		public object Book { get; internal set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>().HasData(
                new Book
                {
                    BookId="1",
                    Title = "abc",
                    Author = "author1",
                    Isbn = 1111222333,
                    Date="10-May-21"
                },
                new Book
                {
                    BookId = "2",
                    Title = "abc2",
                    Author = "author2",
                    Isbn = 333333333,
                    Date = "20-May-21"
                },
                new Book
                {
                    BookId = "3",
                    Title = "abc3",
                    Author = "author3",
                    Isbn = 4444444444,
                    Date = "15-May-21"
                }
            );
        }


    }
}
