﻿using BookCatalogue.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookCatalogue.Repository
{
	public interface IBookRepo
	{
		IEnumerable<Book> GetBookDetails();

		void DeleteBook(string BookId);

		void InsertBook(Book book);

		void UpdateBook(Book book);

		Book GetBookById(Book book);


	}
}
