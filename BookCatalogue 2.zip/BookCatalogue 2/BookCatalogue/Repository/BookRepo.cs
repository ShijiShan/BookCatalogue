﻿using BookCatalogue.DBContexts;
using BookCatalogue.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookCatalogue.Repository
{
	public class BookRepo :IBookRepo
	{
		private readonly BookDetails _dbContext;
		public BookRepo(BookDetails dbContext)
		{
			_dbContext = dbContext;
		}

		public void DeleteBook(string BookId)
		{
			var book = _dbContext.Books.Find(BookId);
			_dbContext.Books.Remove(book);
			Save();
		}

		public IEnumerable<Book> GetBookDetails()
		{
			return _dbContext.Books.ToList();
		}

		public void InsertBook(Book book)
		{
			_dbContext.Add(book);
			Save();
		}
		public void Save()
		{
			_dbContext.SaveChanges();
		}
		public void UpdateBook(Book book)
		{
			_dbContext.Entry(book).State = EntityState.Modified;
			Save();
		}

		Book IBookRepo.GetBookById(Book book)
		{
			return _dbContext.Books.Find(book);
		}
	}
}
