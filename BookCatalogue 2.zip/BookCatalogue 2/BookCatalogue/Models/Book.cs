﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookCatalogue.Models
{
	public class Book
	{
		
	    public string BookId { get; set; }
		public string Title { get; set; }

		public string Author { get; set; }

		public double Isbn { get; set; }

		public string Date { get; set; }


	}
}
