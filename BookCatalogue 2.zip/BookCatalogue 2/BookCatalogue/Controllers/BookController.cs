﻿using BookCatalogue.Models;
using BookCatalogue.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookCatalogue.Controllers
{
	[Route("api/[controller]/[action]")]
	[ApiController]
	public class BookController : ControllerBase
	{
		private readonly IBookRepo dbBook;

		public BookController(IBookRepo bookRepo)
		{
			dbBook = bookRepo;
		}

		// GET: api/<BookController>
		[HttpGet]
		public IActionResult GetAllBooks()
		{
			var books = dbBook.GetBookDetails();
			return new OkObjectResult(books);
			
		}

		// GET api/<BookController>/5
		[HttpGet("{id}")]
		public IActionResult GetBookById(Book book)
		{
			var bookById = dbBook.GetBookById(book);
			return new OkObjectResult(bookById);
		}

		// POST api/<BookController>
		[HttpPost]
		public IActionResult InsertBook([FromBody] Book book)
		{
			using (var scope = new TransactionScope())
			{
				dbBook.InsertBook(book);
				scope.Complete();
				return CreatedAtAction(nameof(dbBook), new { id = book.BookId }, book);
			}
		}

		// PUT api/<BookController>/5
		[HttpPut]
		public IActionResult UpdateBook([FromBody] Book book)
		{
			if (book != null)
			{
				using (var scope = new TransactionScope())
				{
					dbBook.UpdateBook(book);
					scope.Complete();
					return new OkResult();
				}
			}
			return new NoContentResult();
		}

		// DELETE api/<BookController>/5
		[HttpDelete("{id}")]
		public IActionResult DeleteBook(string id)
		{
			dbBook.DeleteBook(id);
			return new OkResult();
		}
	}
}
